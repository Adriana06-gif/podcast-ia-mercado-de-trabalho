# Podcast: Como a Inteligência Artificial está mudando o mercado de trabalho 🎙️🤖

Este projeto foi desenvolvido como parte do desafio da DIO sobre uso de IA na criação de podcasts. Nele, explorei o uso de prompts e ferramentas de voz sintética para criar um episódio de aproximadamente 5 minutos com conteúdo informativo e atual.

## 🎯 Tema

**"Como a Inteligência Artificial está mudando o mercado de trabalho"**  
Aborda os impactos da IA em diversas profissões, apresenta exemplos práticos e destaca a importância da adaptação dos profissionais ao novo cenário tecnológico.

## 💡 Ferramentas Utilizadas

- ChatGPT (OpenAI) – geração do roteiro via prompt
- [Ferramenta de Voz IA] – conversão do roteiro em áudio
- Git e GitHub – versionamento e publicação do projeto

## 📁 Estrutura do Projeto

- `prompts/`: Prompt usado para gerar o roteiro
- `roteiro/`: Texto completo do episódio
- `audio/`: Áudio em formato `.mp3` com a narração gerada por IA

## 🔗 Links úteis

- [Repositório original do desafio](https://github.com/felipeAguiarCode/prompts-for-podcast-generate-by-ia)

## ✍️ Autor

Projeto criado por [Seu Nome Aqui].
